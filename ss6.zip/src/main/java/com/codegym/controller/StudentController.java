package com.codegym.controller;

import com.codegym.dto.StudentCreateDTO;
import com.codegym.model.Student;
import com.codegym.service.IStudentService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
//Tương đương với URLPattern/value ở module 3
@RequestMapping("student")
public class StudentController {

//    @RequestMapping(value = "/hello")
    //Lấy: list, detail, search,..
//    @GetMapping("/")
    //Tạo
//    @PostMapping
    //Cập nhật toàn bộ 1 object
//    @PutMapping
////    Cập nhật 1 phần hoặc toàn bộ object
//    @PatchMapping
//
//    //Xóa
//    @DeleteMapping

//    @GetMapping(consumes = "text/html", produces = "text/html", params = {})

    @Autowired
    private IStudentService iStudentService;
    @GetMapping("")
    public ModelAndView displayList() {

       return new ModelAndView("list", "students", iStudentService.getAll());
    }

    @GetMapping("/detail")
    public String detailByParam(@RequestParam Integer codeStudent,
                                Model model) {
        Student student = iStudentService.getStudentById(codeStudent);
        model.addAttribute("student", student);
        return "detail";
    }

    @GetMapping("/detail/{id}")
    public String detailByPathVariable(@PathVariable("id") Integer codeStudent,
                                Model model) {
        Student student = iStudentService.getStudentById(codeStudent);
        model.addAttribute("student", student);
        return "detail";
    }

    @GetMapping("/create")
    public String viewCreate(Model model) {
//        String[] genders = new String[] {"Nam", "Nữ", "Khác"};
//        model.addAttribute("genders", genders);
        model.addAttribute("studentCreateDTO", new StudentCreateDTO());
        return "create";
    }

    //@ModelAttribute
//    @PostMapping("/create")
//    public String createStudent(@RequestParam Integer codeStudent,
//                                @RequestParam String nameStudent,
//                                @RequestParam Double point,
//                                @RequestParam Integer gender, RedirectAttributes redirect) {
//        Student student = new Student(codeStudent, nameStudent, point, gender);
//        redirect.addFlashAttribute("msg", "Add student successfully");
//        iStudentService.save(student);
//        return "redirect:/student";
//    }

    @PostMapping("/create")
    public String createStudent(@ModelAttribute("studentCreateDTO") StudentCreateDTO studentCreateDTO, BindingResult bindingResult, RedirectAttributes redirect) {
//        Student student = new Student(codeStudent, nameStudent, point, gender);

        redirect.addFlashAttribute("msg", "Add student successfully");
//        Student student = new Student(studentCreateDTO.getCodeStudent(), )
        Student student = new Student();
        //Yeeu cầu khi mapping: Trùng tên và kiểu dữ liệu của thuộc tính.
        BeanUtils.copyProperties(studentCreateDTO, student);

        iStudentService.save(student);
        return "redirect:/student";
    }

}
